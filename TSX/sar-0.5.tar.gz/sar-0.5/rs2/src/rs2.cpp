/*
 *  Copyright (C) 2012 Walter M. Szeliga
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <iostream>
#include <boost/filesystem.hpp>
#include <boost/date_time/posix_time/posix_time_io.hpp>
#include <libgen.h>
#include "ezETAProgressBar.hpp"
#include "xpath_static.h"
#include "tiffio.h"
#include "rs2.hh"

RS2::RS2(const std::string filename) : Sensor()
{
    boost::filesystem::path pathname(filename);
    directory = pathname.parent_path().string();
    if (pathname.parent_path().empty()) {
        directory = ".";
    }
    document = new TiXmlDocument();
    this->document->LoadFile(filename.c_str());

    this->populatePlatform();
    this->populateInstrument();
    this->populateScene();
    this->populateOrbit();
}

RS2::~RS2()
{
    delete this->document;
}

void RS2::populatePlatform()
{
  TIXML_STRING tmp = TinyXPath::S_xpath_string(this->document->RootElement(),
                  "/product/sourceAttributes/satellite/text()");
  std::string satelliteID(tmp.c_str());

  this->instrument->getPlatform()->setMission(satelliteID);
}

void RS2::populateInstrument()
{
    double c = 299792458.0;
    double frequency = TinyXPath::d_xpath_double(this->document->RootElement(), 
                    "/product/sourceAttributes/radarParameters/radarCenterFrequency/text()");
    double wavelength = c/frequency;
    double prf = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/sourceAttributes/radarParameters/pulseRepetitionFrequency/text()");

    double pulseLength = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/sourceAttributes/radarParameters/pulseLength[1]/text()");
    double pulseBandwidth = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/sourceAttributes/radarParameters/pulseBandwidth[1]/text()");
    double chirpSlope = pulseBandwidth/pulseLength;
    double rangePixelSize = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/imageAttributes/rasterAttributes/sampledPixelSpacing/text()");
    double rangeSamplingFrequency = c/(4.0*rangePixelSize);

    this->instrument->setAntennaSide(-1);
    this->instrument->setWavelength(wavelength);
    this->instrument->setPulseRepetitionFrequency(prf);
    this->instrument->setPulseLength(pulseLength);
    this->instrument->setChirpSlope(chirpSlope);
    this->instrument->setAntennaLength(15.0);
    this->instrument->setRangeSamplingFrequency(rangeSamplingFrequency);
    this->instrument->setRangePixelSize(rangePixelSize);
}

void RS2::populateScene()
{
    double c = 299792458.0;
    double height = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/imageGenerationParameters/sarProcessingInformation/satelliteHeight/text()");
    double firstSampleTime = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/imageGenerationParameters/slantRangeToGroundRange/slantRangeTimeToFirstRangeSample/text()");
    double startingRange = firstSampleTime*c/2.0;
    std::string facility = this->readElement("/product/imageGenerationParameters/generalProcessingInformation/processingFacility/text()");
    std::string version = this->readElement("/product/imageGenerationParameters/generalProcessingInformation/softwareVersion/text()");
    std::string passDirection = this->readElement("/product/sourceAttributes/orbitAndAttitude/orbitInformation/passDirection/text()");
    std::string dataStartString = this->readElement("/product/sourceAttributes/rawDataStartTime/text()");
    // Set up the date time formatter
    boost::posix_time::time_input_facet *facet = new boost::posix_time::time_input_facet("%Y-%m-%dT%H:%M:%S%FZ");
    std::stringstream sensingStartString(dataStartString.c_str());
    sensingStartString.imbue(std::locale(sensingStartString.getloc(),facet));
    boost::posix_time::ptime sensingStart;
    sensingStartString >> sensingStart;

    double prf = TinyXPath::d_xpath_double(this->document->RootElement(),
		    "/product/sourceAttributes/radarParameters/pulseRepetitionFrequency/text()");
    int lines = TinyXPath::i_xpath_int(this->document->RootElement(),
		    "/product/imageAttributes/rasterAttributes/numberOfLines/text()");
    double msec = 1e6* double(lines)/prf;
    boost::posix_time::ptime sensingStop = sensingStart + boost::posix_time::microseconds(msec);
    std::string polarization = this->readElement("/product/sourceAttributes/radarParameters/polarizations/text()");
    std::string beam = this->readElement("/product/sourceAttributes/beamModeMnemonic/text()");

    this->scene->setIBias(0.0);
    this->scene->setQBias(0.0);
    this->scene->setStartingRange(startingRange);
    this->scene->setSatelliteHeight(height);
    this->scene->setProcessingFacility(facility);
    this->scene->setProcessingLevel(version);
    this->scene->setPolarization(polarization);
    this->scene->setBeam(beam);
    this->scene->setOrbitNumber(0); // No orbit number information is present in the XML data file
    this->scene->setPassDirection(passDirection);
    this->scene->setSensingStart(sensingStart);
    this->scene->setSensingStop(sensingStop);
}

void RS2::populateOrbit()
{
    double pos[3];
    double vel[3];

    // Get the number of state vectors
    TinyXPath::xpath_processor xp_proc(this->document->RootElement(),
		    "/product/sourceAttributes/orbitAndAttitude/orbitInformation/stateVector");
    unsigned int count = xp_proc.u_compute_xpath_node_set();

    // Set up the date time formatter
    boost::posix_time::time_input_facet *facet = new boost::posix_time::time_input_facet("%Y-%m-%dT%H:%M:%S%F");
    std::stringstream epochString;
    epochString.imbue(std::locale(epochString.getloc(),facet));

    for (unsigned int i=0;i<count;i++) {
        // Parse XML
	TiXmlNode *stateVector = xp_proc.XNp_get_xpath_node(i);
	TIXML_STRING tmp = TinyXPath::S_xpath_string(stateVector,"//timeStamp/text()");
	pos[0] = TinyXPath::d_xpath_double(stateVector,"//xPosition/text()");
	pos[1] = TinyXPath::d_xpath_double(stateVector,"//yPosition/text()");
	pos[2] = TinyXPath::d_xpath_double(stateVector,"//zPosition/text()");
	vel[0] = TinyXPath::d_xpath_double(stateVector,"//xVelocity/text()");
	vel[1] = TinyXPath::d_xpath_double(stateVector,"//yVelocity/text()");
	vel[2] = TinyXPath::d_xpath_double(stateVector,"//zVelocity/text()");

	// Translate the time stamp
	epochString.str(tmp.c_str());
	boost::posix_time::ptime epoch;
	epochString >> epoch;

	// Create State Vector
	StateVector sv = StateVector();
	sv.setTime(epoch);
	sv.setPosition(pos);
	sv.setVelocity(vel);
	this->orbit->addStateVector(sv);
    }
}

SingleBandImage<std::complex<float> > *RS2::extractSlcImage(const std::string filename)
{
    bool azimuthReversed = false;
    int i,j;
    //float *float_buf;
    uint32 width,height;
    FILE *out;
    SingleBandImage<std::complex<float> > *image; 

    // Get the image filename
    TIXML_STRING tmp = TinyXPath::S_xpath_string(this->document->RootElement(),
		    "/product/imageAttributes/fullResolutionImageData/text()");
    std::string input(tmp.c_str());
    std::string imageFile = this->directory + "/" + input;

    // Get the azimuth line ordering
    tmp = TinyXPath::S_xpath_string(this->document->RootElement(),
		    "/product/imageAttributes/rasterAttributes/lineTimeOrdering/text()");
    std::string lineOrdering(tmp.c_str());
    if (lineOrdering.compare(0,10,"Decreasing") == 0) {
	azimuthReversed = true;
    }

    TIFFSetWarningHandler(NULL);
    TIFF *tif = TIFFOpen(imageFile.c_str(),"r");

    if (!tif) {return NULL;}

    uint16 *buf;
    uint32 row;

    //out = fopen(filename.c_str(),"wb");
    TIFFGetField(tif,TIFFTAG_IMAGEWIDTH,&width);
    TIFFGetField(tif,TIFFTAG_IMAGELENGTH,&height);
    try {
        image = new SingleBandImage<std::complex<float> >(filename.c_str(),"w",width,height);
    } catch (std::exception &e) {
	    std::cerr << e.what() << std::endl;
    }

    buf = (uint16 *)_TIFFmalloc(TIFFScanlineSize(tif));
    std::complex<float> *cpx_buf = new std::complex<float>[width];

    ez::ezETAProgressBar pg((unsigned int)height/100);
    pg.start();
    for (row = 0; row < height; row++) {
	if ((row%100) == 0) {++pg;}
        TIFFReadScanline(tif, buf, row);
	for (i=0,j=0;i<2*width;i+=2,j++) {
	    short real = (short)buf[i];
	    short imag = (short)buf[i+1];
	    std::complex<float> cpx_val((float)real,(float)imag);
	    cpx_buf[j] = cpx_val;
            //image->setValue(j,(height-row-1),cpx_val);
	}
	// Some data products are stored with a different azimuth ordering
	if (azimuthReversed) {
	  // These images are stored from late to early in azimuth
	  image->setRow((height-row-1),cpx_buf);
	} else {
	  image->setRow(row,cpx_buf);
	}
	//fwrite(float_buf,sizeof(float),2*width,out);
    }
 
    delete [] cpx_buf;
    TIFFClose(tif);
    //fclose(out);

    // Flush the counter
    std::cout << std::endl;

    return image;
}

/**
 * Convenience function for querying an XML element by an XPATH
 *
 * @param xpath the xpath for the element
 * @return the string value of that element
 */
std::string
RS2::readElement(const char *xpath)
{
    TIXML_STRING tmp = TinyXPath::S_xpath_string(this->document->RootElement(),xpath);
    std::string value(tmp.c_str());

    return value;
}
