/*
 *  Copyright (C) 2012 Walter M. Szeliga
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SENSOR_HH
#define SENSOR_HH 1

#include "metadata/Instrument.hh"
#include "metadata/Scene.hh"
#include "metadata/Orbit.hh"

class Sensor {
	protected:
		Instrument *instrument;
		Scene *scene;
		Orbit *orbit;
	public:
		Sensor();
		~Sensor();
		/**
		 * Return a pointer to the instrument object
		 *
		 * @return
		 */
		Instrument *getInstrument();

		/**
		 * Return a pointer to the Scene object
		 *
		 * @return
		 */
		Scene *getScene();

		/**
		 * Return a pointer to the Orbit object
		 *
		 * @return
		 */
		Orbit *getOrbit();
};

#endif
