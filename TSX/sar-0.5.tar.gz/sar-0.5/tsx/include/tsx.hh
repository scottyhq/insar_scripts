/*
 *  Copyright (C) 2012 Walter M. Szeliga
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef TSX_HH
#define TSX_HH 1

#include <complex>
#include <string>
#include <vector>
#include "Cosar.hh"
#include "metadata/Orbit.hh"
#include "metadata/Instrument.hh"
#include "metadata/Scene.hh"
#include "metadata/Sensor.hh"
#include "image/SingleBandImage.hh"
#include "tinyxml.h"

/**
 * A class for holding Terra-SARX data
 */
class TSX : public Sensor
{
	private:
		std::string directory; // The directory where the XML file resides
		std::string mode; // Image mode
		int numberOfBeams; // Number of beams for ScanSAR
		TiXmlDocument *document;
		Cosar *cosar; // SAR Image data
		void populatePlatform();
		void populateInstrument();
		void populateScene();
		void populateOrbit();
		bool checkImagingMode();
                boost::posix_time::ptime parseTimeString(TIXML_STRING timeString); 
	public:
		TSX(const std::string filename);
		~TSX();
		int getNumberOfBeams();
		std::string getMode();
		SingleBandImage<std::complex<float> > *extractSlcImage(const std::string outFile);
		SingleBandImage<std::complex<float> > *extractSlcImage(const std::string outFile, int beamNumber);
};

#endif

