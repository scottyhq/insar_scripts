#include <string>
#include <fstream>

/** 
 *  @class Header
 *  @brief A class to hold COSAR header data
 *  @author Walter Szeliga
 *  @date 23 Sep. 2010
 */
class Header
{
 private: 
   bool isBigEndian;
   char format[4];
   unsigned int bytesInBurst;
   int rangeSampleRelativeIndex;
   int rangeSamples;
   int azimuthSamples;
   int burstIndex; 
   int rangelineTotalNumberOfBytes;
   int totalNumberOfLines;
   int version;
   int oversamplingFactor;
   double inverseSPECANScalingRate;
 public:
  Header(bool isBigEndian);
  ~Header();
  void parse(std::istream &fin);
  void parse(std::istream &fin,int rangelineNumberOfBytes);
  void print();
  int getRangeSamples();
  int getAzimuthSamples();
  int getRangelineTotalNumberOfBytes();
  int getRangeSampleRelativeIndex();
  int getTotalNumberOfLines();
  int getBytesInBurst();
  int getBurstIndex();
  int getOversamplingFactor();
};
